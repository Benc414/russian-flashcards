Russian Flashcards V2

Files:
- index.html  -> standalone app

Use:
- Open index.html in a browser.
- Best experience on mobile is through a hosted link.
- For quick deployment:
  1. Upload the folder to Vercel, Netlify, or GitHub Pages.
  2. Open the generated URL on your phone.

Features:
- Responsive mobile-first flashcards
- Search, category filter, smart review
- Quiz mode
- Transliteration toggle
- Browser speech synthesis for Russian and English
- Local progress saving

Note:
Speech quality depends on the browser and installed voices.
